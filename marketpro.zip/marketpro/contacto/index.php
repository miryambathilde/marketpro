<?php 
$tituloPagina = "Contacta con nosotros";
$pagina = "contacto";
include('inc/header.php'); ?>

    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="jumbotron">
      <div class="container">
        <h1>Bienvenidos al Marketpro</h1>
        <p>Tu tienda online de confianza donde conseguir los mejores descuentos</p>
        <p><a class="btn btn-primary btn-lg">Ver más &raquo;</a></p>
      </div>
    </div>

    <?php include('inc/footer.php'); ?>
