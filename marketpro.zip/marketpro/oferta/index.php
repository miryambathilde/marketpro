<!--aqui hacemos el require del archivo conf.php
<?php require_once('../inc/conf.php'); ?>

aqui cargamos el archivo de funciones.php DOCUMENT_ROOT es una llamada al directorio raíz -->
<?php include(ROOT.'/inc/funciones.php'); ?>

<!--INCLUDERS -->
<?php 
if (isset($_GET ["id"])) {
  $oferta_id = $_GET["id"];
if (isset($ofertas[$oferta_id])){
$oferta = $ofertas[$oferta_id];
}
} else {
  header("Location: ofertas.php");
  exit();
}

$tituloPagina = "Oferta Destacada";
$pagina = "oferta";
include(ROOT.'/inc/header.php'); 
?>

    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="jumbotron">
      <div class="container">
        <?php echo ofertaDetalle($oferta_id, $oferta);?>
      </div>
    </div>

<?php include(ROOT.'/inc/footer.php'); ?>
