<?php
include('conf.php');
include(ROOT.'/basededatos.php');

function portada($oferta_id, $oferta){

$salida = "";
    
$salida = $salida . '<div class="col-lg-3">';
$salida = $salida . '<h2>'. $oferta["nombre"] . '</h2>';
$salida = $salida . '<img src="/'. $oferta["img"] .'" alt=" '. $oferta["nombre"] . '"class="img-rounded">';
$salida = $salida . '<p>'. $oferta["introDescripcion"] . '</p>';
$salida = $salida . '<p><a class="btn btn-danger" href="oferta/' . $oferta_id .'">Antes '. $oferta["precio"] . '<strong> Ahora '. $oferta["precioOferta"].'</strong></a></p> </div>';
    
return $salida;
    
}
  
function ofertas($oferta_id, $oferta){

  $salida = "";
    
  $salida = $salida . '<div class="col-lg-3">';
  $salida = $salida . '<h2>'. $oferta["nombre"] . '</h2>';
  $salida = $salida . '<img src="'. $oferta["img"] .'" alt=" '. $oferta["nombre"] . '"class="img-rounded">';
  $salida = $salida . '<p>'. $oferta["descripcion"] . '</p>';
  $salida = $salida . '<p><a class="btn btn-danger" href="oferta.php?id=' . $oferta_id .'">Antes '. $oferta["precio"] . '<strong> Ahora '. $oferta["precioOferta"].'</strong></a></p> </div>';
      
  return $salida;
      
}

function ofertaDetalle($oferta_id, $oferta){

  $salida = "";
  
  $salida = $salida . '<div class="row">';
  $salida = $salida . '<div class= "col-md-8">';
  $salida = $salida . '<img src="'. $oferta["img"] .'" alt=" '. $oferta["nombre"] . '"class="img-rounded">';
  $salida = $salida . '<h2>'. $oferta["nombre"] . '</h2>';
  $salida = $salida . '<p>'. $oferta["descripcion"] . '</p></div>';

  $salida = $salida . '<div class="col-md-4">';
  $salida = $salida . '<p><a class="btn btn-danger" href="oferta.php?id=' . $oferta_id .'">Antes '. $oferta["precio"] . '<strong> Ahora '. $oferta["precioOferta"].'</strong></a></p> </div>';
      
  return $salida;
      
}
?>


